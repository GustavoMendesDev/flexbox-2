package school.sptech;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ArgumentsSource;
import school.sptech.provider.CalcularLucroTotalProvider;
import school.sptech.provider.CalcularSeloTomatometroProvider;
import school.sptech.provider.CalcularValorIngressoProvider;

import java.lang.reflect.Method;

import school.sptech.provider.ValidarSalaProvider;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DisplayName("Cinema")
class CinemaTest {

    @Nested
    @DisplayName("validarSala()")
    class ValidarSalaTest {

        @ParameterizedTest
        @DisplayName("Deve validar corretamente a sala")
        @ArgumentsSource(ValidarSalaProvider.class)
        void testValidarSala(Integer sala, Boolean valorEsperado)
              throws ReflectiveOperationException {

            Class<Cinema> clazz = Cinema.class;
            Method method = clazz.getDeclaredMethod("validarSala", Integer.class);

            method.setAccessible(true);

            Cinema obj = new Cinema();
            Boolean salaValida = (Boolean) method.invoke(obj, sala);

            assertEquals(valorEsperado, salaValida);
        }
    }

    @Nested
    @DisplayName("calcularValorIngresso()")
    class CalcularValorIngressoTest {

        @ParameterizedTest
        @DisplayName("Deve calcular corretamente o valor do ingresso")
        @ArgumentsSource(CalcularValorIngressoProvider.class)
        void testCalcularValorIngresso(Integer sala, Boolean meiaEntrada, Double valorEsperado)
              throws ReflectiveOperationException {

            Class<Cinema> clazz = Cinema.class;
            Method method = clazz.getDeclaredMethod("calcularValorIngresso", Integer.class,
                  Boolean.class);

            method.setAccessible(true);

            Cinema obj = new Cinema();
            Double valorIngresso = (Double) method.invoke(obj, sala, meiaEntrada);

            assertEquals(valorEsperado, valorIngresso, 0.01);
        }
    }

    @Nested
    @DisplayName("calcularLucroTotal()")
    class CalcularLucroTotalTest {

        @ParameterizedTest
        @DisplayName("Deve calcular o lucro total corretamente")
        @ArgumentsSource(CalcularLucroTotalProvider.class)
        void testCalcularLucroTotal(Integer[] salas, Boolean[] estudantes, Double valorEsperado)
            throws ReflectiveOperationException {

            Class<Cinema> clazz = Cinema.class;
            Method method = clazz.getDeclaredMethod("calcularLucroTotal", Integer[].class,
                  Boolean[].class);

            method.setAccessible(true);

            Cinema obj = new Cinema();
            Double lucroTotal = (Double) method.invoke(obj, salas, estudantes);

            assertEquals(valorEsperado, lucroTotal, 0.01);
        }
    }

    @Nested
    @DisplayName("calcularSeloTomatometro()")
    class CalcularSeloTomatometroTest {

        @ParameterizedTest
        @DisplayName("Deve calcular o selo do Tomatômetro corretamente")
        @ArgumentsSource(CalcularSeloTomatometroProvider.class)
        void testCalcularSeloTomatometro(Boolean[] reviews, String valorEsperado)
            throws ReflectiveOperationException {

            Class<Cinema> clazz = Cinema.class;
            Method method = clazz.getDeclaredMethod("calcularSeloTomatometro", Boolean[].class);

            method.setAccessible(true);

            Cinema obj = new Cinema();
            String seloTomatometro = (String) method.invoke(obj, (Object) reviews);

            assertEquals(valorEsperado, seloTomatometro);
        }
    }
}
