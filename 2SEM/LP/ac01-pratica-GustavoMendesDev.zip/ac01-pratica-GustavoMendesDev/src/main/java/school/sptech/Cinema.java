package school.sptech;

public class Cinema {

    Boolean validarSala(Integer sala) {
        if (sala.equals(1) || sala.equals(2) || sala.equals(3) || sala.equals(4)) {
            return true;
        } else {
            return false;
        }
    }

    Double calcularValorIngresso(Integer sala, Boolean meiaEntrada) {
        Double valor = 0.0;
        if (sala == 1 && meiaEntrada == true) {
            valor = 15.00;
        } else if (sala == 2 && meiaEntrada == true) {
            valor = 17.50;
        } else if (sala == 3 && meiaEntrada == true) {
            valor = 20.00;
        } else if (sala == 4 && meiaEntrada == true) {
            valor = 22.50;
        } else if (sala == 1 ) {
            valor = 30.00;
        } else if (sala == 2) {
            valor = 35.00;
        } else if (sala == 3 ) {
            valor = 40.00;
        } else if (sala == 4 ) {
            valor = 45.00;
        }
        return valor;
    }

    Double calcularLucroTotal(Integer[] salas, Boolean[] estudantes) {
        Double preco = 0.0;
        for (int i = 0; i < salas.length; i++) {
            if (salas[i] == 1) {
                if (estudantes[i] == true) {
                    preco += 30.0 / 2;
                } else {
                    preco += 30.0;
                }
            } else if (salas[i] == 2) {
                if (estudantes[i] == true) {
                    preco += 35.0 / 2;
                } else {
                    preco += 35.0;
                }
            } else if (salas[i] == 3) {
                if (estudantes[i] == true) {
                    preco += 40.0 / 2;
                } else {
                    preco += 40.0;
                }
            } else if (salas[i] == 4) {
                if (estudantes[i] == true) {
                    preco += 45.0 / 2;
                } else {
                    preco += 45.0;
                }
            }
        }
        preco = preco * 0.10;
        return preco;
    }

    String calcularSeloTomatometro(Boolean[] reviews) {
        Double fresh = 0.0;
        Double rotten = 0.0;

        for (Boolean review : reviews) {
            if (review == true) {
                fresh++;
            } else {
                rotten++;
            }
        }
        Double score = (fresh / reviews.length) * 100;
        if (score >= 60.0) {
            return "fresh";
        }
            return "rotten";
    }
}